Discord = require('discord.js')

const client = new Discord.Client();

const prefix = '-';

var num = 0;

//------------------------------------FILE HANDLER------------------------------------------------

const fs = require('fs');

client.commands = new Discord.Collection();

const commandFiles = fs.readdirSync('./commandsfile/').filter(file => file.endsWith('.js'));
for(const file of commandFiles){
	const command = require(`./commandsfile/${file}`);
		client.commands.set(command.name, command);
		
}
		
//------------------------------------FILE HANDLER------------------------------------------------


client.on('ready', () =>{
	console.log('hrrm')
	client.user.setActivity(`Hmming Problems away`, { type: 'WATCHING' })
}
)

//------------------------------------COUNT------------------------------------------------

client.on('message', (msg) =>{
	
    if(msg.content.startsWith("hm") || msg.content.startsWith("hrm") || msg.content.startsWith("HRM") || msg.content.startsWith("HM")) {
      num++;
        //return msg.channel.send(num); 
}}
)

//------------------------------------COUNT------------------------------------------------

client.on('message', message => {
	if (!message.content.startsWith(prefix) || message.author.bot) return;
	
	const args = message.content.slice(prefix.length).trim().split(/ +/);
	const command = args.shift().toLowerCase();
	
	if(command === 'count'){
		
		const hmmcount = new Discord.MessageEmbed()
.setAuthor('Hrman the Hrmllager','https://media.discordapp.net/attachments/807184058437468160/807184114057740339/Hrmm.png?width=513&height=513',)
.setTitle('Global Hmm Count')
.addField(`Hrms gathered by all users`, `${num}`)
.setColor('fca103')
.setFooter('Hrm Bot by Knight')

message.channel.send(hmmcount);
	}
//--------------------------------------HELP COMMAND-----------------------------------------
else if(command === 'help'){

const huh = new Discord.MessageEmbed()
.setAuthor('Hrman the Hrmllager','https://media.discordapp.net/attachments/807184058437468160/807184114057740339/Hrmm.png?width=513&height=513',)
.setTitle('Hrm Bot Info')
.addField(`About`, `**Hrm Bot** is a simple and stupid bot that tracks how many 'Hmms' and 'Hrmms' users have said globally.`+
`\n`+`and records it.\nIdea by: Varier#8903\n\nDeveloped by: ๖ۣۜKetchaps#0735`, false)
.addField('Commands','**-count**'+'\n'+'Shows the total Hmms and Hrmms users\nin servers that the bot is in has sent.',false)
.setColor('03fc07')
.setFooter('Hrm Bot by Knight.')
message.channel.send(huh)

}
//--------------------------------------HELP COMMAND-----------------------------------------
		
	}
)


client.on('message', message => {
	//if (!message.content.startsWith(prefix) || message.author.bot) return;

	//const args = message.content.slice(prefix.length).trim().split(/ +/);
	//const command = args.shift().toLowerCase();

	if (message.content.startsWith('ping')) {
		message.channel.send('Pong.');
	} else if (message.content.startsWith('beep')) {
		message.channel.send('Boop.');
	};
}
)

client.login('ODA3MTA3NDc3NTk3NzE2NTEw.YBzLaQ.b3XGE2tMutjBFQgDfVKJ8C-7NQ4')