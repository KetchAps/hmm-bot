module.exports = {
name: 'count',
description: "desc",
execute(message, args){
const Discord = require('discord.js');
//import { num } from './main.js'
const hmmcount = new Discord.MessageEmbed()
.setAuthor('Hrman the Hrmllager','https://media.discordapp.net/attachments/807184058437468160/807184114057740339/Hrmm.png?width=513&height=513',)
.setTitle('Global Hmm Count')
.addField(`Hmms gathered by all users`, `${num}`)
.setColor('fca103')
.setFooter('Hmm Bot by Knight')

message.channel.send(hmmcount)
}}

